import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;
public class DecimationSimulation {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Step 1: Prompt the user for the size of the population and reduction percentage
        System.out.print("Enter the size of the population to decimate: ");
        int populationSize = scanner.nextInt();

        System.out.print("Enter the percentage to reduce the population by: ");
        double reductionPercentage = scanner.nextDouble();

        // Calculate the reduction ratio X
        int reduceBy = (int) Math.round(100 / reductionPercentage);

        // Step 2: Create an array and populate it with random numbers
        int[] populationArray = new int[populationSize];
        Random random = new Random();

        for (int i = 0; i < populationSize; i++) {
            populationArray[i] = random.nextInt(99) + 1; // random positive integers between 1 and 99
        }

        // Step 3: Display the original array
        System.out.println("\nThe array before a 1 in " + reduceBy + " reduction:");
        displayArray(populationArray, reduceBy);

        // Step 4: Call myDecimator() method
        myDecimator(populationArray, reduceBy);

        // Step 5: Display the modified array
        System.out.println("/nThe array after a 1 in " + reduceBy + " reduction:");
        displayArray(populationArray, reduceBy);
    }

    // Method to display the array in rows of length X
    public static void displayArray(int[] orgArray, int reduceBy) {
        for (int i = 0; i < orgArray.length; i++) {
            System.out.print(orgArray[i] + " ");
            if ((i + 1) % reduceBy == 0) {
                System.out.println(); // start a new line after every reduceBy elements
            }
        }
        System.out.println();
    }
    
    
    

    // Method to "kill" 1 element in each group by setting its value to 0
    public static void myDecimator(int[] orgArray, int reduceBy) {
        Random random = new Random();
        for (int i = 0; i < orgArray.length; i += reduceBy) {
            int randomIndex = i + random.nextInt(reduceBy);
            orgArray[randomIndex] = 0;
        }
    }	
}
